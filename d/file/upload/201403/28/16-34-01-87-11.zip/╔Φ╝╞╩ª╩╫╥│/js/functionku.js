 // <!-- 显示隐藏div城市 -->
 function cityshow(){ 
		 	document.getElementById('oyw_city_qh').style.display = "block";
		 	document.getElementById('oyw_city_showa').className="oyw_city_showover";
			} 
     	 function cityhide(){ 
     	 	document.getElementById('oyw_city_qh').style.display = "none";
     	 	document.getElementById('oyw_city_showa').className ="oyw_city_showout";
     	}

   // 颜色
   