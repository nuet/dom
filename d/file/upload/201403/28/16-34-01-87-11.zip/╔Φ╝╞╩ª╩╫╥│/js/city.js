// city.js
// 城市切换js
$(document).ready(function(){
   
     function cityshow(){ document.getElementById('oyw_city_qh').style.display = "block"; } 
     function cityhide(){ document.getElementById('oyw_city_qh').style.display = "none"; }
    //隐藏和显示div层   
            function changeDisplay(){   
                var helloDivObj = $("#helloDiv");   
                var buttonObj = $("#btnDisplay");   
                var val = buttonObj.attr("value");   
               if(val=="隐藏"){   
                    helloDivObj.hide();   
                    buttonObj.attr("value","显示");   
                }else{   
                    helloDivObj.show();   
                    buttonObj.attr("value","隐藏");   
                }   
    }   
   
    
})
 function cityshow(){ 
            document.getElementById('oyw_city_qh').style.display = "block";
            document.getElementById('oyw_city_showa').className="oyw_city_showover";
            } 
         function cityhide(){ 
            document.getElementById('oyw_city_qh').style.display = "none";
            document.getElementById('oyw_city_showa').className ="oyw_city_showout";
        }
window.onload=function(){
var timeout         = 100;
var closetimer      = 0;
var ddmenuitem      = 0;

function jsddm_open()
{   jsddm_canceltimer();
    jsddm_close();
    ddmenuitem = $(this).find('ul').eq(0).css('visibility', 'visible');}

function jsddm_close()
{   if(ddmenuitem) ddmenuitem.css('visibility', 'hidden');}

function jsddm_timer()
{   closetimer = window.setTimeout(jsddm_close, timeout);}

function jsddm_canceltimer()
{   if(closetimer)
    {   window.clearTimeout(closetimer);
        closetimer = null;}}

$(document).ready(function()
{   $('#jsddm > li').bind('mouseover', jsddm_open);
    $('#jsddm > li').bind('mouseout',  jsddm_timer);});

document.onclick = jsddm_close;
}

function omover(navbg){
         var parent = document.getElementById("parent");
         parent.className = parent.className + " cur";  //添加classname
    }

// 颜色选择
function listHover(){
    // $(this).addClass('hover').siblings().removeClass('hover');
}
$(function(){
    
    
    //帮我挑选
    (function(){
    
    //颜色
        $('#j-start-color li').hover(function(){
            $(this).children('span').addClass('hover');
        },function(){
            $(this).children('span').removeClass('hover');  
        });
        $('#j-start-color li').click(function(){
            $(this).parent().next().val($(this).attr('j_val'));
            $(this).children('span').addClass('current').parent().siblings().children('span').removeClass('current');
        });
        
        //提交
        $('#j-start-submit').click(function(){
            $(this).parent().parent().submit();
            return false;
        });
    })();
    
});
        $(function(){       
    //建站资料切换
    $('.js_title-list li').click(function(){
        var liindex = $('.js_title-list li').index(this);
        $(this).addClass('on').siblings().removeClass('on');
        $('.product-wrap div.js_product').eq(liindex).fadeIn(150).siblings('div.js_product').hide();
       
    });
    
    //建设资料hover效果
    $('.product-wrap .js_product li').hover(function(){
        $(this).css("border-color","#ff6600");
       
    },function(){
        $(this).css("border-color","#fafafa");
        
    });
    });

// 设计师首页展示切换
 $(function(){       
    //设计师首页切换
    $('.u_shejis_index_all_title_list li').click(function(){
        var liindex = $('.u_shejis_index_all_title_list li').index(this);
        $(this).addClass('on').siblings().removeClass('on');
        $('.u_shejis_index_wrap div.sjs_index_xmsh').eq(liindex).fadeIn(150).siblings('div.sjs_index_xmsh').hide();
        var liWidth = $('.u_shejis_index_all_title_list li').width();
       
    });
    $("#u_shejis_li_bg li:even").addClass("Grey");
    //设计师首页展示hover效果
    $('.u_shejis_index_wrap .sjs_index_xmsh li').hover(function(){
        $(this).css("border-color","#ff6600");
      
    },function(){
        $(this).css("border-color","#ccc");
      
    });
    });
 //设计师评价jQuery 行背景颜色的交替显示(隔行变色)实现代码
//显示单双行显示不同背景色【方法一】： 
// $("#UL_id li:even").attr("className","redClass"); 
//显示单双行显示不同背景色【方法二】： 

// 点击图片放大
$(function(){
    $(".sjs_index_xmsh_img img").click(function(){
        $(this).css("width","+50px");

})
});
