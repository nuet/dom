(function($) {
	var escapeable=/["\\\x00-\x1f\x7f-\x9f]/g,meta= {
	"\b":"\\b","\t":"\\t","\n":"\\n","\f":"\\f","\r":"\\r",'"':'\\"',"\\":"\\\\"
}
;$.toJSON=typeof JSON==="object"&&JSON.stringify?JSON.stringify:function(o) {
	if(o===null) {
	return"null"
}
var type=typeof o;
	if(type==="undefined") {
	return undefined
}
if(type==="number"||type==="boolean") {
	return""+o
}
if(type==="string") {
	return $.quoteString(o)
}
if(type==="object") {
	if(typeof o.toJSON==="function") {
	return $.toJSON(o.toJSON())
}
if(o.constructor===Date) {
	var month=o.getUTCMonth()+1,day=o.getUTCDate(),year=o.getUTCFullYear(),hours=o.getUTCHours(),minutes=o.getUTCMinutes(),seconds=o.getUTCSeconds(),milli=o.getUTCMilliseconds();
	if(month<10) {
	month="0"+month
}
if(day<10) {
	day="0"+day
}
if(hours<10) {
	hours="0"+hours
}
if(minutes<10) {
	minutes="0"+minutes
}
if(seconds<10) {
	seconds="0"+seconds
}
if(milli<100) {
	milli="0"+milli
}
if(milli<10) {
	milli="0"+milli
}
return'"'+year+"-"+month+"-"+day+"T"+hours+":"+minutes+":"+seconds+"."+milli+'Z"'}if(o.constructor===Array) {
	var ret=[];
	for(var i=0;
	i<o.length;
	i++) {
	ret.push($.toJSON(o[i])||"null")
}
return"["+ret.join(",")+"]"}var name,val,pairs=[];
	for(var k in o) {
	type=typeof k;
	if(type==="number") {
	name='"'+k+'"'
}
else {
	if(type==="string") {
	name=$.quoteString(k)
}
else {
	continue
}
}type=typeof o[k];
	if(type==="function"||type==="undefined") {
	continue
}
val=$.toJSON(o[k]);
	pairs.push(name+":"+val)}return" {
	"+pairs.join(",")+"
}
"}};
	$.evalJSON=typeof JSON==="object"&&JSON.parse?JSON.parse:function(src) {
	return eval("("+src+")")
}
;$.secureEvalJSON=typeof JSON==="object"&&JSON.parse?JSON.parse:function(src) {
	var filtered=src.replace(/\\["\\\/bfnrtu]/g,"@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,"]").replace(/(?:^|:|,)(?:\s*\[)+/g,"");
	if(/^[\],: {
	}\s]*$/.test(filtered)) {
	return eval("("+src+")")
}
else {
	throw new SyntaxError("Error parsing JSON,source is not valid.")
}
};
	$.quoteString=function(string) {
	if(string.match(escapeable)) {
	return'"'+string.replace(escapeable,function(a) {
	var c=meta[a];
	if(typeof c==="string") {
	return c
}
c=a.charCodeAt();
	return"\\u00"+Math.floor(c/16).toString(16)+(c%16).toString(16)})+'"'}return'"'+string+'"'}})(jQuery);
	function setCookieMills(b,c,e) {
	var d=new Date();
	d.setTime(d.getTime()+e);
	var a=window.document.domain.indexOf("360buy")>=0?".360buy.com":".jd.com";
	document.cookie=b+"="+escape(c)+";
	expires="+d.toGMTString()+";
	path=/;
	domain="+a
}
function getCookie(b) {
	var a=document.cookie.match(new RegExp("(^| )"+b+"=([^;
	]*)(;
	|$)"));
	if(a!=null) {
	return unescape(a[2])
}
return null}function deleteCookie(a) {
	var b=getCookie(a);
	if(b!=null) {
	setCookieMills(a,"",-1)
}
}function seClick(b,d,f) {
	var a="seWids"+b;
	var c=getCookie(a);
	if(c!=null) {
	var e=c.toString().indexOf(f);
	if(e<0) {
	c=c+","+f
}
}else {
	c=f
}
setCookieMills(a,c,86400000);
	log(2,2,d,f)}function appendJSONCookie(cookieName,key,wid,Mills) {
	var ns=eval("("+getCookie(cookieName)+")");
	if(ns==null||ns=="") {
	ns=new Object()
}
if(ns[key]==null) {
	ns[key]=""
}
var pos=ns[key].indexOf(wid);
	if(pos<0) {
	ns[key]=ns[key]+","+wid
}
setCookieMills(cookieName,$.toJSON(ns),Mills)}function reBook(b,f,a) {
	var e="_rtbook";
	var c=f.toString().split("#")[0];
	appendJSONCookie(e,b,c,86400000);
	log(3,b,c,a)
}
function fe(a,b,c) {
	log("f",a,b,c)
}
function reClick2012(a,e,b) {
	var d="reHome2012";
	var c=e.toString().split("#")[0];
	appendJSONCookie(d,a,c,86400000);
	log(3,a,c,b)
}
function reClickCube(e,b) {
	var a="_rdCube";
	appendJSONCookie(a,"p"+e,b,86400000)
}
function mark(b,a) {
	log(1,a,b)
}
function isMeta(b) {
	if(b.metaKey||b.altKey||b.ctrlKey||b.shiftKey) {
	return true
}
var c=b.which,a=b.button;
	if(!c&&a!==undefined) {
	return(!a&1)&&(!a&2)&&(a&4)
}
else {
	if(c===2) {
	return true
}
else {
	if(a===2) {
	return true
}
}}return false}document.onclick=function(f) {
	f=f||event;
	var r=document;
	var a=tag=f.srcElement||f.target;
	var i=$(tag).attr("clstag");
	var m=f.clientX+Math.round((screen.width-r.body.scrollWidth-17)/2),l=f.clientY+(r.body.scrollTop||r.documentElement.scrollTop),u=r.body.clientWidth,p=r.body.scrollHeight;
	var o="";
	while(!i) {
	tag=tag.parentNode;
	if(!tag||(tag.nodeName=="BODY")) {
	break
}
i=$(tag).attr("clstag")}if(i) {
	var c=i.split("|"),b=c[1],n=c[2],q=c[3];
	if(b==="keycount") {
	$(a).attr("href")?log(n,q,"Q",$(a).attr("href")):log(n,q,"Q");
	o=n+"|"+q;
	if($(a).attr("href")&&/http:\/\/.*?/.exec($(a).attr("href"))&&$(a).attr("target")!=="_blank"&&!isMeta(f)) {
	f.preventDefault?f.preventDefault():f.returnValue=false;
	setTimeout(function() {
	window.location.href=$(a).attr("href")
}
,200)}}}var h=this.location.hostname.toLowerCase();
	var g=/(sale)|(mall)|(jmall)|(pop).360buy.com/;
	if(g.test(h)) {
	log("d","c",o||"-",m+"x"+l,u+"x"+p)
}
};
	function HashMap() {
	this.values=new Object()
}
HashMap.prototype.Set=function(a,b) {
	this.values[a]=b
}
;HashMap.prototype.Get=function(a) {
	return this.values[a]
}
;HashMap.prototype.Contains=function(a) {
	return this.values.hasOwnProperty(a)
}
;HashMap.prototype.Remove=function(a) {
	delete this.values[a]
}
;var SucInfoMethod= {
	Init:function() {
	this.orderDetailMap=new HashMap();
	this.rSM=new HashMap();
	var b=SucInfo_OrderDetail.toString().split(",");
	for(var c=0;
	c<b.length;
	c++) {
	var a=b[c].split(":");
	this.orderDetailMap.Set(a[0],a[1]);
	this.sku=a[0]
}
},GetSkuNum:function(a) {
	return this.orderDetailMap.Get(a)
}
,Contains:function(a) {
	return this.orderDetailMap.Contains(a)
}
,GetDefaultSku:function() {
	return this.sku
}
,ARS:function(a) {
	this.rSM.Set(a,0)
}
,RSContains:function(a) {
	if(this.rSM.Contains(a)) {
	return 1
}
else {
	return 0
}
}};
	function RecommendTrans(recName,tag,logtype) {
	var cookieNames=recName.split(",");
	for(var i=0;
	i<cookieNames.length;
	i++) {
	var recCookies=eval("("+getCookie(cookieNames[i])+")");
	for(var k in recCookies) {
	if(recCookies[k]!="") {
	if(k=="cai2012") {
	loginfo(recCookies[k],k.toString(),"R",logtype)
}
else {
	loginfo(recCookies[k],k.toString(),tag,logtype)
}
}}}}function simpleMold(d,a,g,f,b) {
	for(var e=0;
	e<d.length;
	e++) {
	var c=getCookie(g+d[e]);
	if(c!=null&&c!="") {
	loginfo(c,d[e],a,f,b)
}
}}function complexMold(cookieArrary,tag,prefix,logtype,flag) {
	for(var i=0;
	i<cookieArrary.length;
	i++) {
	var items=eval("("+getCookie(prefix+cookieArrary[i])+")");
	if(items!=null) {
	for(var k in items) {
	if(items[k]!="") {
	loginfo(items[k],k.toString(),tag,logtype,flag)
}
}}}}function loginfo(k,j,a,e,h) {
	var g=k.split(",");
	var c=SucInfo_OrderId,f=SucInfo_OrderType,b=SucInfo_OrderDetail;
	for(var d=0;
	d<g.length;
	d++) {
	if(g[d].length>0) {
	var l=g[d].toString().split("#")[0];
	if(SucInfoMethod.Contains(l)) {
	if(h) {
	log(e,a,j.concat(".o"),c,f,b,l+":"+SucInfoMethod.GetSkuNum(l));
	log("4","R"+j.concat(".o"),c,f,b,l,SucInfoMethod.GetSkuNum(l))
}
else {
	log(e,a+j,c,f,b,l,SucInfoMethod.GetSkuNum(l))
}
}}}}function isChecked() {
	SucInfo_OrderId=window.SucInfo_OrderId||JA.util.getParameter(document.location.href,"suc_orderid")||undefined;
	SucInfo_OrderType=window.SucInfo_OrderType||JA.util.getParameter(document.location.href,"suc_ordertype")||undefined;
	SucInfo_OrderDetail=window.SucInfo_OrderDetail||decodeURIComponent(JA.util.getParameter(document.location.href,"suc_sku"))||undefined;
	return SucInfo_OrderId&&SucInfo_OrderDetail
}
function funLoad() {
	var a=getCookie("pin");
	if(a!=null&&a.length>0) {
	setCookieMills("rpin",a,259200000)
}
}function Clublog() {
	var b=this.location.pathname.toLowerCase();
	var a=this.location.hostname.toLowerCase();
	if((b.indexOf("/cart.html",0)>=0)||(b.indexOf("shoppingcart",0)>=0)) {
	log("R2&Page","Show")
}
else {
	if(b.indexOf("user_home",0)>=0) {
	log("R3&Page","Show")
}
else {
	if((b.indexOf("initcart.html",0)>=0)||(b.indexOf("addtocart.html",0)>=0)||(b.indexOf("initcart.aspx",0)>=0)) {
	log("R4R5&Page","Show")
}
else {
	if((b.indexOf("normal/list.action",0)>=0)||(b.indexOf("orderlist.aspx",0)>=0)) {
	log("DDR&Page","Show")
}
else {
	if(a=="home.360buy.com") {
	if(b=="/") {
	log("R3&Page","Show")
}
}}}}}}function getHistory() {
	var b=decodeURIComponent(escape(getCookie("pin")));
	var d=getCookie("_ghis");
	var c=window.document.location.host.toLowerCase().indexOf("360buy.com")>=0?"360buy":"jd";
	if(d==null&&b!=null) {
	var a="http://gh."+c+".com/BuyHistory.aspx?mid="+encodeURIComponent(b);
	$.ajax( {
	url:a,type:"GET",dataType:"jsonp",success:function(e) {
	var f=e.SSkus;
	var g=e.UserInsterest;
	if(f.toString().length>0) {
	setCookieMills("_ghis",f.toString().substring(0,51))
}
if(g.toString().length>0) {
	setCookieMills("_ghit",g)
}
}})}}(function() {
	function HashMap() {
	this.values=new Object()
}
HashMap.prototype.Set=function(key,value) {
	this.values[key]=value
}
;HashMap.prototype.Get=function(key) {
	return this.values[key]
}
;HashMap.prototype.Contains=function(key) {
	return this.values.hasOwnProperty(key)
}
;HashMap.prototype.Remove=function(key) {
	delete this.values[key]
}
;function SortedHashMap(IComparer,IGetKey) {
	this.IComparer=IComparer;
	this.IGetKey=IGetKey;
	this.a=new Array();
	this.h=new HashMap()
}
SortedHashMap.prototype.Add=function(key,value) {
	if(this.ContainsKey(key)) {
	this.Remove(key)
}
this.a.push(value);
	this.a.sort(this.IComparer);
	for(var i=0;
	i<this.a.length;
	i++) {
	var key=this.IGetKey(this.a[i]);
	this.h.Set(key,i)
}
};
	SortedHashMap.prototype.Insert=function(value,maxlength) {
	for(var i=0,l=this.a.length;
	i<l;
	i++) {
	if(this.a[i].s===value.s) {
	this.a.splice(i,1);
	break
}
}if(this.a.length>=maxlength) {
	this.a.splice(maxlength-1,1)
}
this.a.unshift(value)};
	SortedHashMap.prototype.Get=function(key) {
	return this.a[this.h.Get(key)]
}
;SortedHashMap.prototype.Count=function() {
	return this.a.length
}
;SortedHashMap.prototype.Remove=function(key) {
	if(!this.h.Contains(key)) {
	return
}
var index=this.h.Get(key);
	this.a.splice(index,1);
	this.h.Remove(key)};
	SortedHashMap.prototype.ContainsKey=function(key) {
	return this.h.Contains(key)
}
;SortedHashMap.prototype.Clear=function() {
	this.a=new Array();
	this.h=new HashMap()
}
;SortedHashMap.prototype.GetJson=function() {
	return $.toJSON(this.a)
}
;function ThirdType(thirdType,sku,value) {
	this.t=thirdType;
	this.v=5;
	this.s=0;
	if(arguments.length>1) {
	this.s=sku
}
if(arguments.length>2) {
	this.v=value
}
}ThirdType.prototype.Increase=function() {
	this.v=this.v+2
}
;ThirdType.prototype.Decrease=function() {
	this.v=this.v-1
}
;ThirdType.prototype.SetSku=function(sku) {
	this.s=sku
}
;function Viewrecord(t,s) {
	this.t=t;
	this.s=s
}
function Viewsort(t,s) {
	this.t=t;
	this.s=s;
	this.v=5
}
Ttracker= {
	IComparer:function(a,b) {
	return b.v-a.v
}
,IGetKey:function(a) {
	return a.t
}
,isbook:function(id) {
	return id>10000000&&id<20000000
}
,trace:function() {
	var crumb=$(".breadcrumb span a");
	if(crumb.length<2) {
	return
}
var thref=$(crumb[1]).attr("href");
	if(thref===""||thref==undefined) {
	return
}
var sortidmaths=thref.match(/[http:\/\/\w*?.\w*?.com]*\/[products\/]*\d*-\d*-(\d*).html/i);
	var sortid=(sortidmaths&&sortidmaths.length==2)?sortidmaths[1]:0;
	if(!sortid) {
	return
}
var wid=$("#name").attr("PshowSkuid")||(pageConfig?(pageConfig.product?pageConfig.product.skuid:0):0);
	this.view(sortid,wid);
	this.viewtypewid()},viewtypewid:function() {
	var maps=Ttracker.util.Vv("typewid");
	if(maps) {
	Ttracker.util.Wv("typewid","",-63072000000)
}
},viewhisotry:function(t,s,cname) {
	var nview= {
	t:t,s:s
}
;var bookmap=new SortedHashMap(this.IComparer,this.IGetKey);
	var bview=Ttracker.util.Vv(cname);
	if(bview) {
	try {
	if(bview.indexOf(".")>0) {
	var viewarray=bview.split("|");
	for(var j=viewarray.length-1;
	j>=0;
	j--) {
	var book=viewarray[j].split(".");
	bookmap.Insert( {
	t:Number(book[0]),s:Number(book[1])
}
,8)}}else {
	var bviews=eval("("+bview+")");
	if(bviews.length>0&&bviews[0].d!=undefined) {
	Ttracker.util.Wv(cname,"",-63072000000)
}
else {
	for(var i=bviews.length-1;
	i>=0;
	i--) {
	bookmap.Insert(bviews[i],8)
}
}}}catch(e) {
	Ttracker.util.Wv(cname,"",-63072000000)
}
}bookmap.Insert(nview,8);
	var cvalue="";
	for(var k=0,klen=bookmap.a.length;
	k<klen;
	k++) {
	cvalue+=(bookmap.a[k].t+"."+bookmap.a[k].s+(k==klen-1?"":"|"))
}
cvalue&&Ttracker.util.Wv(cname,cvalue,63072000000)},viewrate:function(t,s,cname) {
	var ntw= {
	t:t,s:s,v:5
}
;var sitesortmap=new SortedHashMap(this.IComparer,this.IGetKey);
	var vrate=Ttracker.util.Vv(cname);
	if(vrate) {
	try {
	if(vrate.indexOf(".")>0) {
	var ratearray=vrate.split("|");
	for(var j=ratearray.length-1;
	j>=0;
	j--) {
	var tw=ratearray[j].split(".");
	var tv=Number(tw[2]||0),tid=Number(tw[0]);
	tv=t===tid?tv:(tv-1);
	sitesortmap.Add(Number(tw[0]) {
	t:Number(tw[0]),s:Number(tw[1]),v:tv
}
,8)}}else {
	var vrates=eval("("+vrate+")");
	if(vrates.length>0&&vrates[0].d!=undefined) {
	Ttracker.util.Wv(cname,"",-63072000000)
}
else {
	for(var i=0;
	i<vrates.length;
	i++) {
	var rate=vrates[i];
	if(rate.t!=t) {
	rate.v-=1
}
sitesortmap.Add(rate.t,rate)}}}}catch(e) {
	Ttracker.util.Wv(cname,"",-63072000000)
}
}if(!sitesortmap.ContainsKey(t)) {
	sitesortmap.Add(t,ntw)
}
else {
	var curtt=sitesortmap.Get(t);
	curtt.s=s?s:curtt.s;
	curtt.v+=2
}
if(sitesortmap.Count()>8) {
	var del=sitesortmap.a[sitesortmap.Count()-1];
	sitesortmap.Remove(del.t)
}
var cvalue="";
	for(var k=0,klen=sitesortmap.a.length;
	k<klen;
	k++) {
	cvalue+=(sitesortmap.a[k].t+"."+sitesortmap.a[k].s+"."+sitesortmap.a[k].v+(k==klen-1?"":"|"))
}
cvalue&&Ttracker.util.Wv(cname,cvalue,63072000000)},view:function(t,s) {
	var tid=Number(t),sku=Number(s);
	if(this.isbook(sku)) {
	this.viewhisotry(tid,sku,"bview");
	this.viewrate(tid,sku,"btw")
}
sku&&this.viewhisotry(tid,sku,"aview");
	this.viewrate(tid,sku,"atw")}};
	Ttracker.util= {
	Wv:function(n,v,t) {
	var d=window.document.domain.indexOf("360buy")>=0?".360buy.com":".jd.com";
	n=n+"="+v+";
	path=/;
	";t&&(n+="expires="+(new Date(new Date().getTime()+t)).toGMTString()+";
	");
	n+="domain="+d+";
	";document.cookie=n
}
,Vv:function(n) {
	for(var b=[],c=document.cookie.split(";
	"),n=RegExp("^\\s*"+n+"=\\s*(.*?)\\s*$"),d=0;
	d<c.length;
	d++) {
	var e=c[d]["match"](n);
	e&&b.push(e[1])
}
return b[0]}};
	Ttracker.trace()})();
	(function() {
	var ac=window,ao=document,aC=encodeURIComponent,ad=decodeURIComponent,R=void 0,N="push",F="join",J="split",Q="length",w="indexOf",m="prototype",H="toLowerCase";
	var r= {
	};
	r.util= {
	join:function(l) {
	if(l instanceof Array) {
	var s="";
	for(var p=0,g=l.length;
	p<g;
	p++) {
	s+=l[p]+((p==g-1)?"":"|||")
}
return s}return l},getParameter:function(p,l) {
	var s=new RegExp("(?:^|&|[?]|[/])"+l+"=([^&]*)");
	var g=s.exec(p);
	return g?aC(g[1]):""
}
,Wv:function(s,g,p,l) {
	s=s+"="+g+";
	path=/;
	";l&&(s+="expires="+(new Date(new Date().getTime()+l)).toGMTString()+";
	");
	p&&(s+="domain="+p+";
	");
	ao.cookie=s
}
,Vv:function(y) {
	for(var g=[],t=ao.cookie[J](";
	"),l=RegExp("^\\s*"+y+"=\\s*(.*?)\\s*$"),s=0;
	s<t[Q];
	s++) {
	var p=t[s]["match"](l);
	p&&g[N](p[1])
}
return g}};
	var aI=0;
	function ai(g) {
	return(g?"_":"")+aI++
}
var al=ai(),ae=ai(),ah=ai(),I=ai(),d=ai(),aK=ai(),X=ai(),ap=ai(),af=ai(),aj=ai(),az=ai(),ay=ai(),aG=ai(),aP=ai(),Z=ai(),U=ai(),B=ai(),z=ai(),M=ai(),aB=ai(),n=ai(),A=ai(),i=ai(),a=ai(),aN=ai(),aw=ai(),P=ai(),aL=ai(),f=ai(),au=ai(),c=ai(),aq=ai(),aT=ai(),b=ai(),ax=ai();
	var aO=function() {
	var s= {
	};
	this.set=function(y,t) {
	s[y]=t
}
;this.get=function(t) {
	return s[t]!==R?s[t]:null
}
;this.m=function(C) {
	var t=this.get(C);
	var D=t==R||t===""?0:1*t;
	s[C]=D+1
}
;this.set(al,"UA-J2011-1");
	var l=window.document.domain.indexOf("360buy")>=0?"360buy.com":"jd.com";
	this.set(I,l);
	this.set(ah,k());
	this.set(d,Math.round((new Date).getTime()/1000));
	this.set(aK,15552000000);
	this.set(X,1296000000);
	this.set(ap,1800000);
	this.set(aP,T());
	var g=ab();
	this.set(Z,g.name);
	this.set(U,g.version);
	this.set(B,G());
	var p=aJ();
	this.set(z,p.D);
	this.set(M,p.C);
	this.set(aB,p.language);
	this.set(n,p.javaEnabled);
	this.set(A,p.characterSet);
	this.set(aL,an);
	this.set(aT,new Date().getTime())};
	var an="baidu:wd,baidu:word,so.com:q,so.360.cn:q,360so.com:q,360sou.com:q,baidu:q1,m.baidu:word,m.baidu:w,wap.soso:key,m.so:q,page.yicha:key,sz.roboo:q,i.easou:q,wap.sogou:keyword,google:q,soso:w,sogou:query,youdao:q,ucweb:keyword,ucweb:word,114so:kw,yahoo:p,yahoo:q,live:q,msn:q,bing:q,aol:query,aol:q,daum:q,eniro:search_word,naver:query,pchome:q,images.google:q,lycos:query,ask:q,netscape:query,cnn:query,about:terms,mamma:q,voila:rdata,virgilio:qs,alice:qs,yandex:text,najdi:q,seznam:q,search:q,wp:szukaj,onet:qt,szukacz:q,yam:k,kvasir:q,ozu:q,terra:query,rambler:query".split(","),aS=function() {
	return Math.round((new Date).getTime()/1000)
}
,v=function() {
	return Math.round(Math.random()*2147483647)
}
,Y=function() {
	return v()^am()&2147483647
}
,k=function() {
	return V(ao.domain)
}
,aJ=function() {
	var l= {
	},g=ac.navigator,p=ac.screen;
	l.D=p?p.width+"x"+p.height:"-";
	l.C=p?p.colorDepth+"-bit":"-";
	l.language=(g&&(g.language||g.browserLanguage)||"-")[H]();
	l.javaEnabled=g&&g.javaEnabled()?1:0;
	l.characterSet=ao.characterSet||ao.charset||"-";
	return l
}
,T=function() {
	var D,C,y,t;
	y="ShockwaveFlash";
	if((D=(D=window.navigator)?D.plugins:R)&&D[Q]>0) {
	for(C=0;
	C<D[Q]&&!t;
	C++) {
	y=D[C],y.name[w]("Shockwave Flash")>-1&&(t=y.description[J]("Shockwave Flash ")[1])
}
}else {
	y=y+"."+y;
	try {
	C=new ActiveXObject(y+".7"),t=C.GetVariable("$version")
}
catch(s) {
	}if(!t) {
	try {
	C=new ActiveXObject(y+".6"),t="WIN 6,0,21,0",C.AllowScriptAccess="always",t=C.GetVariable("$version")
}
catch(p) {
	}
}
if(!t) {
	try {
	C=new ActiveXObject(y),t=C.GetVariable("$version")
}
catch(l) {
	}
}
t&&(t=t[J](" ")[1][J](","),t=t[0]+"."+t[1]+" r"+t[2])}var K=r.util.Vv("_r2");
	D=t?(t+(K[Q]>0?("_"+K[0]):"")):"-";
	var g=r.util.Vv("limgs");
	D=D+(g[Q]>0?("_"+g[0]):"");
	return D},ar=function(g) {
	return R==g||"-"==g||""==g
}
,V=function(l) {
	var g=1,s=0,p;
	if(!ar(l)) {
	g=0;
	for(p=l[Q]-1;
	p>=0;
	p--) {
	s=l.charCodeAt(p),g=(g<<6&268435455)+s+(s<<14),s=g&266338304,g=s!=0?g^s>>21:g
}
}return g},am=function() {
	var p=aJ();
	for(var l=p,g=ac.navigator,l=g.appName+g.version+l.language+g.platform+g.userAgent+l.javaEnabled+l.D+l.C+(ao.cookie?ao.cookie:"")+(ao.referrer?ao.referrer:""),g=l.length,s=ac.history.length;
	s>0;
	) {
	l+=s--^g++
}
return V(l)},ab=function() {
	var g= {
	name:"other",version:"0"
}
,s=navigator.userAgent.toLowerCase();
	browserRegExp= {
	se360:/360se/,se360_2x:/qihu/,ie:/msie[ ]([\w.]+)/,firefox:/firefox[|\/]([\w.]+)/,chrome:/chrome[|\/]([\w.]+)/,safari:/version[|\/]([\w.]+)(\s\w.+)?\s?safari/,opera:/opera[|\/]([\w.]+)/
}
;for(var p in browserRegExp) {
	var l=browserRegExp[p].exec(s);
	if(l) {
	g.name=p;
	g.version=l[1]||"0";
	break
}
}return g},G=function() {
	var g=/(win|android|linux|nokia|ipad|iphone|ipod|mac|sunos|solaris)/.exec(navigator.platform.toLowerCase());
	return g==null?"other":g[0]
}
,aH=function() {
	var p="",y=["jwotest_product","jwotest_list","jwotest_cart","jwotest_orderinfo","jwotest_homepage","jwotest_other1","jwotest_other2","jwotest_other3"];
	for(var t=0,g=y.length;
	t<g;
	t++) {
	var s=r.util.Vv(y[t]);
	if(s[Q]==0) {
	continue
}
var C=ad(s[0]).match(/=(.*?)&/gi),l=[];
	if(C==null) {
	continue
}
$.each(C,function(K,D) {
	l.push(K==0?"T"+D.substring(1,D.length-1):D.substring(1,D.length-1))
}
);
	p+=l[F]("-")+";
	"}return p},aF=function(s) {
	s.set(af,ao.location.hostname);
	s.set(aj,ao.title.replace(/\$/g,""));
	s.set(az,ao.location.pathname);
	s.set(ay,ao.referrer.replace(/\$/g,""));
	s.set(aG,ao.location.href);
	var g=r.util.Vv("__jda"),K=g[Q]>0?g[0][J]("."):null;
	s.set(ae,K?K[1]:Y());
	s.set(i,K?K[2]:s.get(d));
	s.set(a,K?K[3]:s.get(d));
	s.set(aN,K?K[4]:s.get(d));
	s.set(aw,K?K[5]:1);
	var y=r.util.Vv("__jdv"),t=y[Q]>0?y[0][J]("|"):null;
	s.set(f,t?t[1]:"direct");
	s.set(au,t?t[2]:"-");
	s.set(c,t?t[3]:"none");
	s.set(aq,t?t[4]:"-");
	var D=r.util.Vv("__jdb"),C=D[Q]>0?D[0][J]("."):null;
	s.set(P,C?C[1]:0);
	s.set(b,aH()||"-");
	var p=JA.util.Vv("clickid"),l=p[Q]&&p[0];
	s.set(ax,l);
	return !0
}
,aD=function() {
	var l=r.util.Vv("__jdb"),g=l[Q]>0?l[0][J]("."):null;
	return(g&&g.length==4)?g[1]*1:0
}
,aE=function(aZ) {
	var t=ao.location.href,D=ao.referrer,aW=aZ.get(I),C=r.util.getParameter(t,"utm_source"),y=[],W=aZ.get(f),O=aZ.get(au),L=aZ.get(c),l=r.util.Vv("__jdb")[Q]==0,g=r.util.Vv("__jdv")[Q]==0;
	if(C) {
	var p=r.util.getParameter(t,"utm_campaign"),aY=r.util.getParameter(t,"utm_medium"),aa=r.util.getParameter(t,"utm_term");
	y[N](C);
	y[N](p||"-");
	y[N](aY||"-");
	y[N](aa||"not set");
	aZ.set(aq,y[3])
}
else {
	var s=D&&D[J]("/")[2],aX=false;
	if(s&&s[w](aW)<0) {
	for(var ak=aZ.get(aL),aU=0;
	aU<ak.length;
	aU++) {
	var aV=ak[aU][J](":");
	if(s[w](aV[0][H]())>-1&&D[w]((aV[1]+"=")[H]())>-1) {
	var K=r.util.getParameter(D,aV[1]);
	y[N](aV[0]);
	y[N]("-");
	y[N]("organic");
	y[N](K||"not set");
	aZ.set(aq,y[3]);
	aX=true;
	break
}
}if(!aX) {
	if(s[w]("zol.com.cn")>-1) {
	y[N]("zol.com.cn");
	y[N]("-");
	y[N]("cpc");
	y[N]("not set")
}
else {
	y[N](s);
	y[N]("-");
	y[N]("referral");
	y[N]("-")
}
}}}if(l||g||(!l&&y[Q]>0&&(y[0]!==W||y[1]!==O||y[2]!==L)&&y[2]!=="referral")) {
	aZ.set(f,y[0]||aZ.get(f));
	aZ.set(au,y[1]||aZ.get(au));
	aZ.set(c,y[2]||aZ.get(c));
	aZ.set(aq,y[3]||aZ.get(aq));
	at(aZ)
}
else {
	h(aZ)
}
},j=function(l,g) {
	var p=g.split(".");
	l.set(i,p[2]);
	l.set(a,p[4]);
	l.set(aN,aS());
	l.m(aw);
	l.set(P,1)
}
,E=function(l) {
	var g=l.get(d);
	l.set(ae,Y());
	l.set(i,g);
	l.set(a,g);
	l.set(aN,g);
	l.set(aw,1);
	l.set(P,1)
}
,h=function(g) {
	g.m(P)
}
,u=function(g) {
	return[g.get(ah),g.get(ae)||"-",g.get(i)||"-",g.get(a)||"-",g.get(aN)||"-",g.get(aw)||1][F](".")
}
,e=function(g) {
	return[g.get(ah),g.get(P)||1,g.get(ae)+"|"+g.get(aw)||1,g.get(aN)||g.get(d)][F](".")
}
,x=function(g) {
	return[g.get(ah),g.get(f)||ao.domain,g.get(au)||"(direct)",g.get(c)||"direct",g.get(aq)||"-"][F]("|")
}
,at=function(g) {
	var l=r.util.Vv("__jda");
	l.length==0?E(g):j(g,l[0])
}
;var q=new aO(),av=function() {
	this.a= {
	};
	this.add=function(g,l) {
	this.a[g]=l
}
;this.get=function(g) {
	return this.a[g]
}
;this.toString=function() {
	return this.a[F]("&")
}
},ag=function(l,g) {
	function s(y,t) {
	t&&p[N](y+"="+t+";
	")
}
var p=[];
	s("__jda",u(l));
	s("__jdv",x(l));
	g.add("jdcc",p[F]("+"))},o=function(l,g) {
	g.add("jdac",l.get(al)),g.add("jduid",l.get(ae)),g.add("jdsid",l.get(ae)+"|"+l.get(aw)),g.add("jdje",l.get(n)),g.add("jdsc",l.get(M)),g.add("jdsr",l.get(z)),g.add("jdul",l.get(aB)),g.add("jdcs",l.get(A)),g.add("jddt",l.get(aj)||"-"),g.add("jdmr",aC(l.get(ay))),g.add("jdhn",l.get(af)||"-"),g.add("jdfl",l.get(aP)),g.add("jdos",l.get(B)),g.add("jdbr",l.get(Z)),g.add("jdbv",l.get(U)),g.add("jdwb",l.get(i)),g.add("jdxb",l.get(a)),g.add("jdyb",l.get(aN)),g.add("jdzb",l.get(aw)),g.add("jdcb",l.get(P)),g.add("jdusc",l.get(f)||"direct"),g.add("jducp",l.get(au)||"-"),g.add("jdumd",l.get(c)||"-"),g.add("jduct",l.get(aq)||"-"),g.add("jdlt",typeof jdpts!="object"?0:jdpts._st==undefined?0:l.get(aT)-jdpts._st),g.add("jdtad",l.get(b)),g.add("jdak",l.get(ax))
}
,aR=function(l,g,p,s) {
	g.add("jdac",l.get(al)),g.add("jduid",l.get(ae)),g.add("jdsid",l.get(ae)+"|"+l.get(aw)),g.add("jdje","-"),g.add("jdsc","-"),g.add("jdsr","-"),g.add("jdul","-"),g.add("jdcs","-"),g.add("jddt","-"),g.add("jdmr",aC(l.get(ay))),g.add("jdhn","-"),g.add("jdfl","-"),g.add("jdos","-"),g.add("jdbr","-"),g.add("jdbv","-"),g.add("jdwb","-"),g.add("jdxb","-"),g.add("jdyb","-"),g.add("jdzb",l.get(aw)),g.add("jdcb",s?(aD()+s):l.get(P)),g.add("jdusc","-"),g.add("jducp","-"),g.add("jdumd","-"),g.add("jduct","-"),g.add("jdlt",0),g.add("jdtad",p),g.add("jdak",l.get(ax))
}
,aQ=function() {
	aF(q)&&aE(q);
	var l=new av(),g=q.get(I);
	o(q,l);
	r.util.Wv("__jda",u(q),g,q.get(aK));
	r.util.Wv("__jdb",e(q),g,q.get(ap));
	r.util.Wv("__jdc",q.get(ah),g);
	r.util.Wv("__jdv",x(q),g,q.get(X));
	r.util.Wv("clickid","0",g,-84600000);
	return l.a
}
,aA=function() {
	var g=new av();
	o(q,g);
	return g.a
}
,aM=function(g,l) {
	var p=new av();
	aR(q,p,g,l);
	return p.a
}
;r.tracker= {
	loading:function(t,s,p,y) {
	var C=p&&(p.jdac+"||"+p.jdje+"||"+p.jdsc+"||"+p.jdsr+"||"+p.jdul+"||"+p.jdcs+"||"+aC(p.jddt)+"||"+p.jdhn+"||"+p.jdfl+"||"+p.jdos+"||"+p.jdbr+"||"+p.jdbv+"||"+p.jdwb+"||"+p.jdxb+"||"+p.jdyb+"||"+p.jdzb+"||"+p.jdcb+"||"+p.jdusc+"||"+p.jducp+"||"+p.jdumd+"||"+p.jduct+"||"+p.jdlt+"||"+p.jdtad),g=r.util.Vv("pin");
	var l=("https:"==document.location.protocol?"https://cscssl":"http://csc")+".jd.com/log.ashx?type1="+aC(t)+"&type2="+aC(s)+"&pin="+aC(g[Q]>0?g[0]:"-")+"&uuid="+p.jduid+"&sid="+p.jdsid+(p.jdak?("&utmp="+document.location.href+aC("&clickid="+p.jdak)):"")+"&referrer="+aC(p.jdmr||"-")+"&jinfo="+C+"&data="+aC(JA.util.join(y))+"&callback=?";
	$.getJSON(l,function() {
	})
}
,ngloader:function(s,K) {
	var C="";
	for(var g in K) {
	C+=((g+"="+K[g])+"$")
}
C=C.substring(0,C.length-1);
	var l=r.util.Vv("pin"),y=aA();
	var p=("https:"==document.location.protocol?"https://mercuryssl":"http://mercury")+".jd.com/log.gif?t="+s+"&m="+q.get(al)+"&pin="+aC(l)+"&sid="+y.jdsid+(y.jdak?("&cul="+document.location.href+aC("&clickid="+y.jdak)):"")+"&v="+aC(C)+"&ref="+aC(ao.referrer)+"&rm="+Math.random();
	var D=new Image(1,1);
	D.src=p;
	D.onload=function() {
	D.onload=null;
	D.onerror=null
}
;D.onerror=function() {
	D.onload=null;
	D.onerror=null
}
},bloading:function(p,g,s) {
	var l=aQ();
	var t= {
	je:l.jdje,sc:l.jdsc,sr:l.jdsr,ul:l.jdul,cs:l.jdcs,dt:l.jddt,hn:l.jdhn,fl:l.jdfl,os:l.jdos,br:l.jdbr,bv:l.jdbv,wb:l.jdwb,xb:l.jdxb,yb:l.jdyb,zb:l.jdzb,cb:l.jdcb,usc:l.jdusc,ucp:l.jducp,umd:l.jdumd,uct:l.jduct,lt:l.jdlt,ct:s,tad:l.jdtad
}
;r.tracker.ngloader("www.100000",t);
	this.loading(p,g,l,s)},aloading:function(p,l,s) {
	var g=aA();
	this.loading(p,l,g,s)
}
,adshow:function(l) {
	var g=aM(l);
	this.loading("AD","IM",g,"")
}
,adclick:function(l) {
	var g=aM(l,1);
	this.loading("AD","CL",g,"")
}
};
	window.JA=r;
	r.tracker.bloading("J","A",new Date().getTime());
	var S=$(".w .crumb a").length===5&&/e.jd.com\/products\/(\d*)-(\d*)-(\d*).html[\w\W]*?e.jd.com\/(\d*).html/.exec($(".w .crumb").html());
	if((window.pageConfig&&window.pageConfig.product&&window.pageConfig.product.cat)||S) {
	r.tracker.ngloader("item.010001" {
	sku:S[4]||window.pageConfig.product.skuid,cid1:S[1]||window.pageConfig.product.cat[0],cid2:S[2]||window.pageConfig.product.cat[1],cid3:S[3]||window.pageConfig.product.cat[2],brand:S?"0":(window.pageConfig.product.brand||"0")
}
)}(function() {
	if(isChecked()) {
	SucInfoMethod.Init();
	var t=getCookie("_distM");
	if(t&&t==SucInfo_OrderId) {
	return true
}
var g=["p000","p100","np000","np100"];
	for(var s=0;
	s<g.length;
	s++) {
	var C=getCookie(g[s]);
	if(C!=null&&C!="") {
	log("HomePageOrder",g[s])
}
}var p="1:2:3:4:5:1a:1b:BR1:BR2:BR3:BR4:BR5:DDR:GR1:GR2:GR3:GR4:VR1:VR2:VR3:VR4:VR5:NR:CR1:CR2:CR3:SR1:SR2:SR3:SR4:Indiv&Simi:Indiv&OthC:Indiv&AllC:Zd";
	simpleMold(p.split(":"),"R","reWids","4");
	var y="Club,ThirdRec,AttRec,OCRec,SORec,EBRec,BookSpecial,BookTrack,BookHis,Coupon,GlobalTrack,GlobalHis,History,historyreco_s,historyreco_c";
	complexMold(y.split(","),"R","reWids","4");
	var l=["v","TrackRec","TrackHis","CouDan","CarAcc","Zd","Tc","g","s","Book","BookSpecial","BookTrack","BookHis","GlobalTrack","GlobalHis","History","Hiss","Hisc","simi","GThirdRec","PtoAccy","AtoAccy"];
	complexMold(l,"o","rod","d",true);
	RecommendTrans("reHome2012,_rtbook","N","4");
	complexMold(["_rdCube"],"Cube","","4");
	simpleMold(["SEO"],"S","seWids","4");
	setCookieMills("_distM",SucInfo_OrderId,86400000);
	setCookieMills("_ghis","",-1);
	r.tracker.ngloader("order.100000" {
	orderid:SucInfo_OrderId,ordertype:SucInfo_OrderType,orderdetail:SucInfo_OrderDetail
}
);
	log("7","2",SucInfo_OrderId,SucInfo_OrderType,SucInfo_OrderDetail)}})()})();
	function log(c,b) {
	var a=Array.prototype.slice.call(arguments);
	a=a&&a.slice(2);
	JA&&JA.tracker.aloading(c,b,a);
	JA&&JA.tracker.ngloader("other.000000" {
	t1:c,t2:b,p0:JA.util.join(a)
}
)}(function() {
	if(typeof jdpts!="object") {
	return
}
if(jdpts._cls) {
	log(jdpts._cls.split(".")[0],jdpts._cls.split(".")[1])
}
})();
	Clublog();