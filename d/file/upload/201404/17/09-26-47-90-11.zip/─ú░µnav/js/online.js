// $(function(){
// var $wind = $(window);//将浏览器加入缓存中

// var $do = $('#scrollDiv');//将你要改变宽度的div元素加入缓存中
// var win = $wind.outerWidth();//首先获取浏览器的宽度

// $win.resize(function(){

// //浏览器变化宽度的动作。

// var newW = $wind.outerWidth();

// $do.outerWidth(Math.abs(win-newW));

// })

// })
// $("#j_chatClose").click(function() {
// 		return $("#talk_c").trigger("click"),
// 		!1
// 	});
//文字显示隐藏
$(document).ready(function(){        
 $('#j_font').click(function(){
  $(".j_popWord").toggle(1000);
 });
 $('#expressionButton').click(function(){
   // $('.j_popFace').toggle(1000);
   $(".im-pop-face").toggle(1000);

 });
  $('#change').click(function(){
   // $('.j_popFace').toggle(1000);
   $(".im-pop-send-set").toggle(1000);

 });
  $('#j_fontClose').click(function(){
  $(".j_popWord").toggle(1000);
 });
   $('.im-pop-send-set').click(function(){
  $(".im-pop-send-set").toggle(1000);
 });
  $('#j_chatRestore').click(function(){
  $(".im-wrap").css('width','1000px');

 });
    $('.U_Lin_Bqoo').click(function(){
   $(".im-pop-face").toggle(1000);

});
  //   $("#j_chatRestore").click(function() {
  //     var cucishu=1
  //   // if (count == 1) {
  //     $('.im_wrap').animate({
  //       width: "1000px"
  //     });
  //   //   count++;
  //   // } else {
  //   //   $('.im_wrap').animate({
  //   //    width: "100%"
  //   //   });
  //   //   count–;
  //   // }
  // });
 //   $('#j_colorClose').click(function(){
 //  $("#colorPanel").toggle(1000);

 // });
//     var maxCount = 360;  // 最高字数，这个值可以自己配置
//      $("#im-edit-ipt-t").click(function(){
//       alert(maxCount);
//      });
//   $("#im-edit-ipt-t").on('keyup', function() {
//     alert(1);
//     var len = getStrLength(this.value);
//     $("#countSZ").html(maxCount-len);
//   });
 
// // 中文字符判断
// function getStrLength(str) { 
//     var len = str.length; 
//     var reLen = 0; 
//     for (var i = 0; i < len; i++) {        
//         if (str.charCodeAt(i) < 27 || str.charCodeAt(i) > 126) { 
//             // 全角    
//             reLen += 2; 
//         } else { 
//             reLen++; 
//         } 
//     } 
//     return reLen;    
// }
// 限制输入字数
  $("#im-edit-ipt-t").keyup(function(){
var maxl = 120;
var tishi = "" + maxl +"";
$(".im-txt-num").html(tishi);
    var xianyou = $(this).val().length ;
var keyi = maxl - xianyou;
var tishi = "" + keyi +"";
if(xianyou > 120){
 var tishi = "0"
 $(".im-txt-num").css({"color":"red"});
}else if(xianyou > 39){
}else{
}
$(".im-txt-num").html(tishi);
  });
  function clickDOM(){
        tempDOM  = $(this);

}
  // 输入插入
  function clickButton(){
     $("#im-edit-ipt-t").append(tempDOM);

}
  $("#face table tr td img").click(function(){
      alert($("#im-edit-ipt-t").id);
  })
});
// 限制输入字数end

function chat_off(){
  if(confirm('确定要中断聊天吗？')){
    window.close();
  }
}
// $(window).resize(function(){
//   var $OnLheight =($(window).height());
 
//    var $H =($OnLheight-257+'px');

//   // $('.im-chat-list').css('height','$H');

//   $(".im-chat-list").css("height",$H-210);
// });

// if($("#mydiv").is(":visible")==false){
// });