$(document).ready(function(){ 
  
$('.G_X_XQ_XTab_li ul li').hover(function(){
   var liindex = $('.G_X_XQ_XTab_li ul li').index(this);
        $(this).addClass('on').siblings().removeClass('on');
        $('.G_X_XQ_XTabWarm div.G_X_XQ_list').eq(liindex).fadeIn(0).siblings('div.G_X_XQ_list').hide();
        var liWidth = $('.G_X_XQ_XTab_li li').width();
});

});

// city.js
// 城市切换js
$(document).ready(function(){
   
     function cityshow(){ document.getElementById('oyw_city_qh').style.display = "block"; } 
     function cityhide(){ document.getElementById('oyw_city_qh').style.display = "none"; }
    //隐藏和显示div层   
            function changeDisplay(){   
                var helloDivObj = $("#helloDiv");   
                var buttonObj = $("#btnDisplay");   
                var val = buttonObj.attr("value");   
               if(val=="隐藏"){   
                    helloDivObj.hide();   
                    buttonObj.attr("value","显示");   
                }else{   
                    helloDivObj.show();   
                    buttonObj.attr("value","隐藏");   
                }   
    }   
   
    
})
 function cityshow(){ 
            document.getElementById('oyw_city_qh').style.display = "block";
            document.getElementById('oyw_city_showa').className="oyw_city_showover";
            } 
         function cityhide(){ 
            document.getElementById('oyw_city_qh').style.display = "none";
            document.getElementById('oyw_city_showa').className ="oyw_city_showout";
        }
window.onload=function(){
var timeout         = 100;
var closetimer      = 0;
var ddmenuitem      = 0;

function jsddm_open()
{   jsddm_canceltimer();
    jsddm_close();
    ddmenuitem = $(this).find('ul').eq(0).css('visibility', 'visible');}

function jsddm_close()
{   if(ddmenuitem) ddmenuitem.css('visibility', 'hidden');}

function jsddm_timer()
{   closetimer = window.setTimeout(jsddm_close, timeout);}

function jsddm_canceltimer()
{   if(closetimer)
    {   window.clearTimeout(closetimer);
        closetimer = null;}}

$(document).ready(function()
{   $('#jsddm > li').bind('mouseover', jsddm_open);
    $('#jsddm > li').bind('mouseout',  jsddm_timer);});

document.onclick = jsddm_close;
}

// function omover(navbg){
//          var parent = document.getElementById("parent");
//          parent.className = parent.className + " cur";  //添加classname
//     }

// 颜色选择
  // function listHover(){
  //     // $(this).addClass('hover').siblings().removeClass('hover');
  // }
$(function(){
    
    
    //帮我挑选
    (function(){
    
    //颜色
        $('#j-start-color li').hover(function(){
            $(this).children('span').addClass('hover');
        },function(){
            $(this).children('span').removeClass('hover');  
        });
        $('#j-start-color li').click(function(){
            $(this).parent().next().val($(this).attr('j_val'));
            $(this).children('span').addClass('current').parent().siblings().children('span').removeClass('current');
        });
        
        //提交
        $('#j-start-submit').click(function(){
            $(this).parent().parent().submit();
            return false;
        });
    })();
    
});
        $(function(){       
    //建站资料切换
    $('.js_title-list li').click(function(){
        var liindex = $('.js_title-list li').index(this);
        $(this).addClass('on').siblings().removeClass('on');
        $('.product-wrap div.js_product').eq(liindex).fadeIn(150).siblings('div.js_product').hide();
       
    });
    
    //建设资料hover效果
    $('.product-wrap .js_product li').hover(function(){
        $(this).css("border-color","#ff6600");
       
    },function(){
        $(this).css("border-color","#fafafa");
        
    });
    });

// 设计师首页展示切换
 $(function(){       
    //设计师首页切换
    $('.u_shejis_index_all_title_list li').click(function(){
        var liindex = $('.u_shejis_index_all_title_list li').index(this);
        $(this).addClass('on').siblings().removeClass('on');
        $('.u_shejis_index_wrap div.sjs_index_xmsh').eq(liindex).fadeIn(150).siblings('div.sjs_index_xmsh').hide();
        var liWidth = $('.u_shejis_index_all_title_list li').width();
       
    });
    $("#u_shejis_li_bg li:even").addClass("Grey");
    //设计师首页展示hover效果
    $('.u_shejis_index_wrap .sjs_index_xmsh li').hover(function(){
        $(this).css("border-color","#ff6600");
     
        $(this).find('div span').css('display','block');
      
      
    },function(){
        $(this).css("border-color","#ccc");
     
        $(this).find('div span').css('display','none');
       
    });
    });
 //设计师评价jQuery 行背景颜色的交替显示(隔行变色)实现代码
//显示单双行显示不同背景色【方法一】： 
// $("#UL_id li:even").attr("className","redClass"); 
//显示单双行显示不同背景色【方法二】： 

// 点击图片放大
$(function(){
    $(".sjs_index_xmsh_img img").click(function(){
        $(this).css("width","+50px");

})
});
// 设计师大厅展示隔行变色开始
$(function(){
     $("#u_SheJiS_DaTing_List_cont_info p:even").addClass("Grey");
});
// 设计师大厅展示隔行变色结束

// New——Index首页选项案例展示
$(function(){       
    //首页选项案例展示
    $('.InAnL_title_list li').click(function(){
        var liindex = $('.InAnL_title_list li').index(this);
        $(this).addClass('on').siblings().removeClass('on');
        $('.Index_Anli_wrap div.Index_Anli_pro').eq(liindex).fadeIn(150).siblings('div.Index_Anli_pro').hide();
        var liWidth = $('.InAnL_title_list li').width();
       
    });
    $("#u_shejis_li_bg li:even").addClass("Grey");
    //首页选项案例展示hover效果
    $('.Index_Anli_wrap .Index_Anli_pro li').hover(function(){
        $(this).css("border-color","#ff6600");
        $(this).css("-moz-box-shadow","0px 0px 10px #909090");
        $(this).find('div div').css('display','block');
        $(this).find('div img').css('filter','alpha(optacity=70)');
        $(this).find('div img').css('opacity','0.7');
       
    },function(){
        $(this).css("border-color","#ccc");
         $(this).find('div div').css('display','none');
         $(this).find('div img').css('opacity','1');
        $(this).find('div img').css('filter','alpha(opacity=100)');
      
      
    });
    });

/*filter:progid:DXImageTransform.Microsoft.Shadow(color=#909090,direction=120,strength=4);/*ie*/
    /*-moz-box-shadow: 0px 0px 10px #909090;/*firefox*/
    /*-webkit-box-shadow: 0px 0px 10px #909090;/*safari或chrome*/
    /*box-shadow:0px 0px 10px #909090;/*opera或ie9*/
// New——Index首页选项案例展示结束
// 首页显示隐藏透明度

// 首页显示隐藏透明度结束
// 全站搜素页面案例展示开始
$(function(){       
    //案例展示hover效果
    $('.QuanZ_An_List .QuanZ_An_List_ul li').hover(function(){
        $(this).css("border-color","#ff6600");
        $(this).css("-moz-box-shadow","0px 0px 10px #909090");
        $(this).find('div div').css('display','block');
     
       
    },function(){
        $(this).css("border-color","#ccc");
         $(this).find('div div').css('display','none');
           
      
    });
    });

// 全站搜素页面案例展示结束

$(function(){       
    $('.QuanZ_An_List .QuanZ_An_List_ul li').hover(function(){
        $(this).css("-moz-box-shadow","0px 0px 10px #909090");
        $(this).find('div div').css('display','block');
         $(this).find('div img').css('filter','alpha(optacity=80)');
         $(this).find('div img').css('opacity','0.8');
       
    },function(){
        $(this).css("border-color","#ccc");
         $(this).find('div div').css('display','none');
        $(this).find('div img').css('filter','alpha(optacity=100)');
         $(this).find('div img').css('opacity','1.0');
           
      
    });
    });
// 展示收起
$(document).ready(function(){
$("#JS_shouqi_fliter").click(function(){//当点击触发silideToggle
$("#QuanZ_An_S_xz_sq").slideToggle("slow");
$(this).toggleClass("nav1"); return false;//触发后然后改变小图标方向，

});
});

// 案例选择
$(function(){ 
    var  QuanZ_An_biaoqian = $('#QuanZ_An_biaoqian');
  $('.QuanZ_An_Bq_a li a').click(function(){
  $(this).parent().each(function () {//移除其余非点中状态
        $('.QuanZ_An_Bq_a li a').removeClass("special_color");
        });
        $(this).addClass("special_color");//给所点中的增加样式
      var Q_val_a=($(this).text());//输出所点的a的内容
      var BQ_d = $("#QuanZ_An_biaoqian");
   
      var Q_val_a  = '<span>'+Q_val_a+'<a style="cursor:pointer"></a></span>';
    
    $(BQ_d).append(Q_val_a);
    // d.innerHTML = Q_val_a ;
   $("#QuanZ_An_biaoqian span a").click(function(){     
       var span =($(this).parent());
      
        span.remove();
        
   });
   
   
 });
});
// 套房选择
$(function(){ 
    var  QuanZ_An_biaoqian = $('#QuanZ_An_biaoqian');
  $('.QuanZ_An_S_xz_taoc li a').click(function(){
      
      var Q_val_a=($(this).text());//输出所点的a的内容
      var BQ_d = $("#QuanZ_An_biaoqian");
   
      var Q_val_a  = '<span>'+Q_val_a+'<a style="cursor:pointer"></a></span>';
    
    $(BQ_d).append(Q_val_a);
  
   $("#QuanZ_An_biaoqian span a").click(function(){     
       var span =($(this).parent());
      
        span.remove();
        
   });
   
   
 });
});
// 色系选择
$(function(){ 
  var  QuanZ_An_biaoqian = $('#QuanZ_An_biaoqian');
  $('.QuanZ_An_color li a').click(function(){
      // var Q_val_a = ($(this).children());
      var Q_val_a = Q_val_a.text();
    
      var Q_val_a=($(this).text());//输出所点的a的内容
      var BQ_d = $("#QuanZ_An_biaoqian");
   
      var Q_val_a  = '<span>'+Q_val_a+'<a style="cursor:pointer"></a></span>';
    
    $(BQ_d).append(Q_val_a);
  
   $("#QuanZ_An_biaoqian span a").click(function(){     
       var span =($(this).parent());
      
        span.remove();
        
   });
   
   
 });
});

// 登录注册
$(function(){
  $('#L_password').click(function(){

    $(this).val("");
    $(this).type('password');
    return false;
  });
  $('#L_uername').click(function(){

    $(this).val("");
    $(this).type(password);
  });
});
// 注册表单提交
$(function(){
  $('#inp_username').click(function(){

     // var $uinfo ="请输入邮箱/用户名/手机号";
     $span = $(this).next(".Reg_form_span");
      alert($span);
     
    $span.css("display","block");
  });
 
});

// 黄色模版最新企业站模版切换

$(function(){       
     $('.MoBan_yZNew_title_list li').click(function(){
        var liindex = $('.MoBan_yZNew_title_list li').index(this);
        $(this).addClass('on').siblings().removeClass('on');
        $('.MoBan_yZNew_wrap div.MoBan_yZNew_pro').eq(liindex).fadeIn(150).siblings('div.MoBan_yZNew_pro').hide();
        var liWidth = $('.MoBan_yZNew_title_list li').width();
       
    });
    //展示hover效果
    $('.MoBan_yZNew_pro').hover(function(){
        $('.MoBan_yZNew_NQ .sPrev').css('display','block');
         $('.MoBan_yZNew_NQ .sNext').css('display','block');
    },function(){
       $('.MoBan_yZNew_NQ .sPrev').css('display','none');
         $('.MoBan_yZNew_NQ .sNext').css('display','none');
    }
    );
    $('.MoBan_yZNew_wrap .MoBan_yZNew_pro li').hover(function(){
        $(this).css("border-color","#ff6600");
        $(this).css("-moz-box-shadow","0px 0px 10px #909090");
      
        $(this).find('div div').css('display','block');
        $(this).find('div img').css('filter','alpha(optacity=70)');
        $(this).find('div img').css('opacity','0.7');
       
    },function(){
        $(this).css("border-color","#ccc");
         $(this).find('div div').css('display','none');
        
         $(this).find('div img').css('opacity','1');
        $(this).find('div img').css('filter','alpha(opacity=100)');
      
      
    });
    });



// 模版内页选择语言
$(document).ready(function(){         
 $('.M_Ycatt_lagu ul li a').click(function(){
  $(this).addClass('MY_XZLAG');
 });
 $('html').mousedown(function(){
  $('.M_Ycatt_lagu ul li a').removeClass('MY_XZLAG');
 });
});

// 图片放大
(function(jQuery){ 

  jQuery.fn.zoomImgRollover = function(options) {

    var defaults = {
      percent:30,
      duration:600
    }; 

    var opts = jQuery.extend(defaults, options);
    
    // static zoom function
    function imageZoomStep(jZoomImage, x, origWidth, origHeight)
    {
      var width = Math.round(origWidth * (.5 + ((x * opts.percent) / 200))) * 2;
      var height = Math.round(origHeight * (.5 + ((x * opts.percent) / 200))) * 2;
        
      var left = (width - origWidth) / 2;
      var top = (height - origHeight) / 2;
    
      jZoomImage.css({width:width, height:height, top:-top, left:-left});
    }

    return this.each(function()
    {
      var jZoomImage = jQuery(this);
      var origWidth = jZoomImage.width();
      var origHeight = jZoomImage.height();
      
      // add css ness. to allow zoom
      jZoomImage.css({position: "relative"});
      jZoomImage.parent().css({overflow: "hidden", display:"block", position: "relative", width: origWidth, height: origHeight});
      
      jZoomImage.mouseover(function()
      {
        jZoomImage.stop().animate({dummy:1},{duration:opts.duration, step:function(x)
        {
          imageZoomStep(jZoomImage, x, origWidth, origHeight)
        }});
      });

      jZoomImage.mouseout(function()
      {
        jZoomImage.stop().animate({dummy:0},{duration:opts.duration, step:function(x)
        {
          imageZoomStep(jZoomImage, x, origWidth, origHeight)
        }});
      });
    });
  };

})(jQuery);

$(document).ready(function() {
    $(".testimg").zoomImgRollover();
});

// 详情内容导航浮动
$().ready(function(){
    //导航距离屏幕顶部距离
    var _defautlTop = $("#M_Y_XQ_rt_title").offset().top;//假如网速慢，或者页面较长加载较慢时，不能及时获取_defautlTop的值，导致回到页头时无法归位没找到好的解决方法，我增加了document.ready也不行，于是我就写死了这个值
    //导航距离屏幕左侧距离
    var _defautlLeft = $("#M_Y_XQ_rt_title").offset().left;
    //导航默认样式记录，还原初始样式时候需要
    var _position = $("#M_Y_XQ_rt_title").css('position');
    var _top = $("#M_Y_XQ_rt_title").css('top');
    var _left = $("#M_Y_XQ_rt_title").css('left');
    var _zIndex = $("#M_Y_XQ_rt_title").css('z-index');
    //鼠标滚动事件
    $(window).scroll(function(){
        if($(this).scrollTop() > _defautlTop){
            //IE6不认识position:fixed，单独用position:absolute模拟
            if($.browser.msie && $.browser.version=="6.0"){
                $("#top").css({'position':'absolute','top':eval(document.documentElement.scrollTop),'left':_defautlLeft,'z-index':99999});
                //防止出现抖动
                $("html,body").css({'background-image':'url(about:blank)','background-attachment':'fixed'});
            }else{
                $("#M_Y_XQ_rt_title").css({'position':'fixed','top':0,'left':_defautlLeft,'z-index':99999});
            }
        }else{
            $("#M_Y_XQ_rt_title").css({'position':_position,'top':_top,'left':_left,'z-index':_zIndex});
        }
    });
});

$(document).ready(function(){         
 $('.M_Y_XQ_rt_title ul li a').click(function(){
  $(this).addClass('MCon');
 });
 $('html').mousedown(function(){
  $('.M_Y_XQ_rt_title ul li a').removeClass('MCon');
 });
});
// 个性需求tab切换
